import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  const validAdminPasswords = [
    process.env.ADMIN_PASSWORD,
    process.env.ADMIN_PASSWORD_AC,
    process.env.ADMIN_PASSWORD_TEAM,
    process.env.ADMIN_PASSWORD_MAIN
  ].filter(Boolean);

  const isValidAdmin = (password: string | string[] | undefined) => {
    if (!password) return false;
    const pwd = Array.isArray(password) ? password[0] : password;
    return validAdminPasswords.includes(pwd);
  };

  // === MERCHANTS ===
  app.get(api.merchants.list.path, async (req, res) => {
    const merchants = await storage.getAllMerchants();
    res.json(merchants);
  });

  app.get(api.merchants.get.path, async (req, res) => {
    const merchantId = Number(req.params.id);
    const merchant = await storage.getMerchantWithProducts(merchantId);
    if (!merchant) {
      return res.status(404).json({ message: "Merchant not found" });
    }
    res.json(merchant);
  });

  app.post(api.merchants.create.path, async (req, res) => {
    try {
      if (!isValidAdmin(req.headers['x-admin-password'])) {
        return res.status(401).json({ message: "Invalid admin password" });
      }
      const input = api.merchants.create.input.parse(req.body);
      const merchant = await storage.createMerchant(input);
      res.status(201).json(merchant);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      throw err;
    }
  });

  app.delete(api.merchants.delete.path, async (req, res) => {
    try {
      if (!isValidAdmin(req.headers['x-admin-password'])) {
        return res.status(401).json({ message: "Invalid admin password" });
      }
      const id = Number(req.params.id);
      await storage.deleteMerchant(id);
      res.status(204).send();
    } catch (err) {
      res.status(500).json({ message: "Failed to delete merchant" });
    }
  });

  // === PRODUCTS ===
  app.get(api.products.listByMerchant.path, async (req, res) => {
    const merchantId = Number(req.params.id);
    const products = await storage.getProductsByMerchant(merchantId);
    res.json(products);
  });

  app.post(api.products.create.path, async (req, res) => {
    try {
      if (!isValidAdmin(req.headers['x-admin-password'])) {
        return res.status(401).json({ message: "Invalid admin password" });
      }
      const input = api.products.create.input.parse(req.body);
      const product = await storage.createProduct(input);
      res.status(201).json(product);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      throw err;
    }
  });

  app.delete(api.products.delete.path, async (req, res) => {
    try {
      if (!isValidAdmin(req.headers['x-admin-password'])) {
        return res.status(401).json({ message: "Invalid admin password" });
      }
      const id = Number(req.params.id);
      await storage.deleteProduct(id);
      res.status(204).send();
    } catch (err) {
      res.status(500).json({ message: "Failed to delete product" });
    }
  });

  // === TRANSACTIONS ===
  app.post(api.transactions.create.path, async (req, res) => {
    try {
      const input = api.transactions.create.input.parse(req.body);
      const transaction = await storage.createTransaction(input);
      res.status(201).json(transaction);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });
  
  app.get(api.transactions.listByMerchant.path, async (req, res) => {
      const merchantId = Number(req.params.id);
      const transactions = await storage.getTransactionsByMerchant(merchantId);
      res.json(transactions);
  });

  app.delete(api.transactions.delete.path, async (req, res) => {
    try {
      if (!isValidAdmin(req.headers['x-admin-password'])) {
        return res.status(401).json({ message: "Invalid admin password" });
      }
      const id = Number(req.params.id);
      await storage.deleteTransaction(id);
      res.status(204).send();
    } catch (err) {
      res.status(500).json({ message: "Failed to delete transaction" });
    }
  });

  // Seed data on startup
  await storage.seedData();

  return httpServer;
}
