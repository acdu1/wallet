import { db } from "./db";
import {
  merchants,
  products,
  transactions,
  type Merchant,
  type InsertMerchant,
  type Product,
  type InsertProduct,
  type Transaction,
  type InsertTransaction,
  type MerchantWithProducts
} from "@shared/schema";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  // Merchants
  getAllMerchants(): Promise<Merchant[]>;
  getMerchant(id: number): Promise<Merchant | undefined>;
  getMerchantWithProducts(id: number): Promise<MerchantWithProducts | undefined>;
  createMerchant(merchant: InsertMerchant): Promise<Merchant>;
  deleteMerchant(id: number): Promise<void>;
  
  // Products
  getProductsByMerchant(merchantId: number): Promise<Product[]>;
  createProduct(product: InsertProduct): Promise<Product>;
  deleteProduct(id: number): Promise<void>;
  
  // Transactions
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
  getTransactionsByMerchant(merchantId: number): Promise<Transaction[]>;
  deleteTransaction(id: number): Promise<void>;
  
  // Seeding
  seedData(): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getAllMerchants(): Promise<Merchant[]> {
    return await db.select().from(merchants);
  }

  async getMerchant(id: number): Promise<Merchant | undefined> {
    const [merchant] = await db.select().from(merchants).where(eq(merchants.id, id));
    return merchant;
  }

  async getMerchantWithProducts(id: number): Promise<MerchantWithProducts | undefined> {
    const [merchant] = await db.select().from(merchants).where(eq(merchants.id, id));
    if (!merchant) return undefined;

    const merchantProducts = await db.select().from(products).where(eq(products.merchantId, id));
    return { ...merchant, products: merchantProducts };
  }

  async createMerchant(insertMerchant: InsertMerchant): Promise<Merchant> {
    const [merchant] = await db.insert(merchants).values(insertMerchant).returning();
    return merchant;
  }

  async deleteMerchant(id: number): Promise<void> {
    await db.delete(transactions).where(eq(transactions.merchantId, id));
    await db.delete(products).where(eq(products.merchantId, id));
    await db.delete(merchants).where(eq(merchants.id, id));
  }

  async getProductsByMerchant(merchantId: number): Promise<Product[]> {
    return await db.select().from(products).where(eq(products.merchantId, merchantId));
  }

  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    const [product] = await db.insert(products).values(insertProduct).returning();
    return product;
  }

  async deleteProduct(id: number): Promise<void> {
    await db.delete(products).where(eq(products.id, id));
  }

  async createTransaction(transaction: InsertTransaction): Promise<Transaction> {
    const [newTransaction] = await db.insert(transactions).values(transaction).returning();
    return newTransaction;
  }

  async getTransactionsByMerchant(merchantId: number): Promise<Transaction[]> {
    return await db
      .select()
      .from(transactions)
      .where(eq(transactions.merchantId, merchantId))
      .orderBy(desc(transactions.createdAt));
  }

  async deleteTransaction(id: number): Promise<void> {
    await db.delete(transactions).where(eq(transactions.id, id));
  }

  async seedData(): Promise<void> {
    const existingMerchants = await this.getAllMerchants();
    if (existingMerchants.length > 0) return;

    // Create Merchants
    const [coffeeShop] = await db.insert(merchants).values({
      name: "Bean There Coffee",
      slug: "bean-there",
      description: "Artisan coffee and pastries",
      logoUrl: "https://images.unsplash.com/photo-1509042239860-f550ce710b93",
      hours: "7AM - 7PM",
      location: "456 Espresso Blvd, Coffee City"
    }).returning();

    const [techStore] = await db.insert(merchants).values({
      name: "Gadget Galaxy",
      slug: "gadget-galaxy",
      description: "Latest tech accessories",
      logoUrl: "https://images.unsplash.com/photo-1519389950473-47ba0277781c",
      hours: "10AM - 9PM",
      location: "789 Silicon Way, Tech Hub"
    }).returning();
    
    const [bakery] = await db.insert(merchants).values({
        name: "Sweet Tooth Bakery",
        slug: "sweet-tooth",
        description: "Freshly baked goods daily",
        logoUrl: "https://images.unsplash.com/photo-1517433670267-08bbd4be890f",
        hours: "6AM - 3PM",
        location: "123 Muffin Lane, Bakerstown"
    }).returning();

    // Create Products for Coffee Shop
    await db.insert(products).values([
      { merchantId: coffeeShop.id, name: "Espresso", price: 350, description: "Single shot espresso" },
      { merchantId: coffeeShop.id, name: "Latte", price: 450, description: "Creamy latte with oat milk option" },
      { merchantId: coffeeShop.id, name: "Croissant", price: 400, description: "Buttery french croissant" },
    ]);

    // Create Products for Tech Store
    await db.insert(products).values([
      { merchantId: techStore.id, name: "USB-C Cable", price: 1500, description: "2m braided cable" },
      { merchantId: techStore.id, name: "Screen Protector", price: 1000, description: "Tempered glass" },
    ]);
    
    // Create Products for Bakery
    await db.insert(products).values([
        { merchantId: bakery.id, name: "Sourdough Loaf", price: 800, description: "Artisan sourdough bread" },
        { merchantId: bakery.id, name: "Chocolate Cake Slice", price: 650, description: "Rich chocolate ganache" }
    ]);

    console.log("Database seeded successfully!");
  }
}

export const storage = new DatabaseStorage();
