import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// === TABLE DEFINITIONS ===

export const merchants = pgTable("merchants", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(), // For URL friendly merchant pages
  description: text("description"),
  logoUrl: text("logo_url"),
  pin: text("pin").notNull().default("1234"),
  hours: text("hours"),
  location: text("location"),
});

export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  merchantId: integer("merchant_id").notNull(),
  name: text("name").notNull(),
  description: text("description"),
  price: integer("price").notNull(), // Stored in cents
  imageUrl: text("image_url"),
  active: boolean("active").default(true),
});

export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  merchantId: integer("merchant_id").notNull(),
  productId: integer("product_id"), // Nullable for custom amount transactions
  amount: integer("amount").notNull(), // Stored in cents
  description: text("description").notNull(),
  customerQrCode: text("customer_qr_code").notNull(), // The scanned data
  status: text("status").notNull().default("completed"), // completed, failed
  createdAt: timestamp("created_at").defaultNow(),
});

// === RELATIONS ===

export const merchantsRelations = relations(merchants, ({ many }) => ({
  products: many(products),
  transactions: many(transactions),
}));

export const productsRelations = relations(products, ({ one }) => ({
  merchant: one(merchants, {
    fields: [products.merchantId],
    references: [merchants.id],
  }),
}));

export const transactionsRelations = relations(transactions, ({ one }) => ({
  merchant: one(merchants, {
    fields: [transactions.merchantId],
    references: [merchants.id],
  }),
  product: one(products, {
    fields: [transactions.productId],
    references: [products.id],
  }),
}));

// === BASE SCHEMAS ===

export const insertMerchantSchema = createInsertSchema(merchants).omit({ id: true });
export const insertProductSchema = createInsertSchema(products).omit({ id: true });
export const insertTransactionSchema = createInsertSchema(transactions).omit({ id: true, createdAt: true });

// === EXPLICIT API CONTRACT TYPES ===

export type Merchant = typeof merchants.$inferSelect;
export type Product = typeof products.$inferSelect;
export type Transaction = typeof transactions.$inferSelect;

export type InsertMerchant = z.infer<typeof insertMerchantSchema>;
export type InsertProduct = z.infer<typeof insertProductSchema>;
export type InsertTransaction = z.infer<typeof insertTransactionSchema>;

// Request types
export type CreateTransactionRequest = InsertTransaction;

// Response types
export type MerchantWithProducts = Merchant & { products: Product[] };
