## Packages
react-qr-code | To display QR codes if needed (though requirement is scanning)
react-qr-scanner | For scanning customer QR codes
framer-motion | For smooth page transitions and micro-interactions
clsx | For conditional class merging
tailwind-merge | For merging tailwind classes utility
lucide-react | For beautiful icons (already in base, but listing for clarity)

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
}
