import { useState, useEffect } from "react";
import { useRoute, Link, useLocation } from "wouter";
import { useMerchant, useMerchantProducts, useMerchantTransactions, useCreateTransaction } from "@/hooks/use-merchants";
import { motion, AnimatePresence } from "framer-motion";
import { 
  ArrowLeft, 
  Settings, 
  History, 
  Plus, 
  CreditCard,
  DollarSign,
  ChevronRight,
  Package,
  Scan,
  LogOut,
  Trash2,
  Image as ImageIcon
} from "lucide-react";
import { ScannerModal } from "@/components/ScannerModal";
import { TransactionCard } from "@/components/TransactionCard";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger, SheetDescription } from "@/components/ui/sheet";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertProductSchema } from "@shared/schema";
import { api, buildUrl } from "@shared/routes";

export default function MerchantDashboard() {
  const [, params] = useRoute("/merchant/:id");
  const [, setLocation] = useLocation();
  const id = Number(params?.id);
  
  const { data: merchant, isLoading: loadingMerchant } = useMerchant(id);
  const { data: products, isLoading: loadingProducts } = useMerchantProducts(id);
  const { data: transactions, isLoading: loadingTransactions } = useMerchantTransactions(id);
  const createTransaction = useCreateTransaction();
  const { toast } = useToast();

  const [isDeleting, setIsDeleting] = useState<number | null>(null);
  const [addProductOpen, setAddProductOpen] = useState(false);

  const productForm = useForm({
    resolver: zodResolver(insertProductSchema),
    defaultValues: {
      merchantId: id,
      name: "",
      description: "",
      price: 0,
      imageUrl: "",
      active: true
    }
  });

  useEffect(() => {
    if (id && !sessionStorage.getItem(`merchant_auth_${id}`)) {
      setLocation(`/merchant/${id}/login`);
    }
  }, [id, setLocation]);

  const onAddProduct = async (data: any) => {
    const adminPassword = prompt("Please enter admin password to add product:");
    if (!adminPassword) return;

    try {
      // Ensure merchantId is passed as number and other fields are correctly formatted
      const payload = { 
        ...data, 
        merchantId: id,
        price: Number(data.price)
      };
      await apiRequest("POST", api.products.create.path, payload, { "X-Admin-Password": adminPassword });
      queryClient.invalidateQueries({ queryKey: [buildUrl(api.products.listByMerchant.path, { id: id })] });
      setAddProductOpen(false);
      productForm.reset();
      toast({
        title: "Product Added",
        description: `${data.name} has been added to merchant.`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to add product.",
        variant: "destructive",
      });
    }
  };

  const onDeleteProduct = async (productId: number, productName: string) => {
    const adminPassword = prompt(`Please enter admin password to delete "${productName}"`);
    if (!adminPassword) return;

    try {
      await apiRequest("DELETE", buildUrl(api.products.delete.path, { id: productId }), null, { "X-Admin-Password": adminPassword });
      queryClient.invalidateQueries({ queryKey: [buildUrl(api.products.listByMerchant.path, { id: id })] });
      toast({
        title: "Product Deleted",
        description: `${productName} has been removed from merchant.`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to delete product.",
        variant: "destructive",
      });
    }
  };

  const handleDeleteTransaction = async (txId: number) => {
    const adminPassword = prompt("Please enter admin password to delete transaction:");
    if (!adminPassword) return;

    try {
      setIsDeleting(txId);
      await apiRequest("DELETE", buildUrl(api.transactions.delete.path, { id: txId }), null, { "X-Admin-Password": adminPassword });
      queryClient.invalidateQueries({ queryKey: [buildUrl(api.transactions.listByMerchant.path, { id: id })] });
      toast({
        title: "Transaction Deleted",
        description: "The transaction has been removed from history.",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to delete transaction.",
        variant: "destructive",
      });
    } finally {
      setIsDeleting(null);
    }
  };

  const handleLogout = () => {
    sessionStorage.removeItem(`merchant_auth_${id}`);
    setLocation(`/merchant/${id}/login`);
    toast({
      title: "Logged Out",
      description: "You have been securely logged out.",
    });
  };

  // Modal State
  const [scannerOpen, setScannerOpen] = useState(false);
  const [activeItem, setActiveItem] = useState<{ id?: number, name: string, price: number } | null>(null);
  const [isCustomAmount, setIsCustomAmount] = useState(false);
  const [customAmount, setCustomAmount] = useState("");
  const [customDescription, setCustomDescription] = useState("");

  const handleProductClick = (product: any) => {
    setActiveItem({ id: product.id, name: product.name, price: product.price });
    setIsCustomAmount(false);
    setScannerOpen(true);
  };

  const handleCustomCharge = () => {
    if (!customAmount || parseFloat(customAmount) <= 0) {
      toast({
        title: "Invalid Amount",
        description: "Please enter a valid amount greater than 0.",
        variant: "destructive"
      });
      return;
    }
    
    // Convert to cents
    const priceInCents = Math.round(parseFloat(customAmount) * 100);
    
    setActiveItem({ 
      name: customDescription || "Custom Charge", 
      price: priceInCents 
    });
    setIsCustomAmount(true);
    setScannerOpen(true);
  };

  const handleScan = async (qrData: string) => {
    if (!activeItem) return;

    // Validate QR code format: 12 digits starting with 828
    const qrRegex = /^828\d{9}$/;
    if (!qrRegex.test(qrData)) {
      toast({
        title: "Invalid QR Code",
        description: "This scanner only accepts 12-digit codes starting with 828.",
        variant: "destructive"
      });
      setScannerOpen(false);
      return;
    }

    try {
      await createTransaction.mutateAsync({
        merchantId: id,
        productId: isCustomAmount ? undefined : activeItem.id,
        amount: activeItem.price,
        description: activeItem.name,
        customerQrCode: qrData,
        status: "completed"
      });

      setScannerOpen(false);
      setCustomAmount("");
      setCustomDescription("");
      
      toast({
        title: "Payment Successful",
        description: `$${(activeItem.price / 100).toFixed(2)} received from customer.`,
        variant: "default",
        className: "bg-green-600 text-white border-none"
      });
    } catch (error) {
      toast({
        title: "Payment Failed",
        description: error instanceof Error ? error.message : "Something went wrong",
        variant: "destructive"
      });
      setScannerOpen(false);
    }
  };

  if (loadingMerchant) return <div className="h-screen flex items-center justify-center"><div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" /></div>;
  if (!merchant) return <div className="h-screen flex items-center justify-center">Merchant not found</div>;

  return (
    <div className="min-h-screen bg-gray-50 pb-24">
      
      {/* Top Navigation */}
      <nav className="bg-white px-4 py-4 sticky top-0 z-10 border-b flex items-center justify-between shadow-sm">
        <Link href="/" className="p-2 hover:bg-gray-100 rounded-full transition-colors">
          <ArrowLeft className="text-gray-600" size={20} />
        </Link>
        <span className="font-bold text-lg font-display">{merchant.name}</span>
        <div className="flex items-center gap-1">
          <Sheet>
            <SheetTrigger asChild>
              <button className="p-2 hover:bg-gray-100 rounded-full transition-colors">
                <Settings className="text-gray-600" size={20} />
              </button>
            </SheetTrigger>
            <SheetContent>
              <SheetHeader>
                <SheetTitle>Merchant Settings</SheetTitle>
                <SheetDescription>
                  Manage your account and transaction history.
                </SheetDescription>
              </SheetHeader>
              <div className="py-6 space-y-6">
                <div className="space-y-4">
                  <h4 className="text-sm font-bold uppercase tracking-wider text-muted-foreground px-1">
                    Manage Transactions
                  </h4>
                  <div className="border rounded-xl overflow-hidden divide-y">
                    {transactions?.length === 0 ? (
                      <div className="p-4 text-center text-sm text-muted-foreground">
                        No transactions found
                      </div>
                    ) : (
                      transactions?.map((tx) => (
                        <div key={tx.id} className="p-3 flex items-center justify-between bg-white">
                          <div className="min-w-0 flex-1">
                            <p className="text-sm font-medium truncate">{tx.description}</p>
                            <p className="text-xs text-muted-foreground">
                              ${(tx.amount / 100).toFixed(2)} • {tx.createdAt ? new Date(tx.createdAt).toLocaleDateString() : ''}
                            </p>
                          </div>
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="text-destructive hover:text-destructive hover:bg-destructive/10"
                            onClick={() => handleDeleteTransaction(tx.id)}
                            disabled={isDeleting === tx.id}
                          >
                            <Trash2 size={16} />
                          </Button>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </div>
            </SheetContent>
          </Sheet>
          <button 
            onClick={handleLogout}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
            title="Log Out"
          >
            <LogOut className="text-gray-600" size={20} />
          </button>
        </div>
      </nav>

      <main className="max-w-md mx-auto p-4 space-y-8">
        
        {/* Quick Actions (Custom Amount) */}
        <section className="bg-gradient-to-br from-primary to-blue-600 rounded-3xl p-6 text-white shadow-xl shadow-blue-500/20">
          <h2 className="text-lg font-medium opacity-90 mb-4 flex items-center gap-2">
            <CreditCard size={18} />
            Quick Charge
          </h2>
          
          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-4 border border-white/20">
            <div className="flex items-center gap-2 mb-4">
              <span className="text-2xl font-light opacity-80">$</span>
              <input 
                type="text" 
                inputMode="decimal"
                pattern="[0-9]*[.,]?[0-9]*"
                placeholder="0.00"
                value={customAmount}
                onChange={(e) => {
                  const val = e.target.value;
                  if (val === '' || /^\d*[.,]?\d{0,2}$/.test(val)) {
                    setCustomAmount(val.replace(',', '.'));
                  }
                }}
                className="bg-transparent text-4xl font-bold w-full focus:outline-none placeholder:text-white/40"
              />
            </div>
            <input 
              type="text" 
              placeholder="What is this for? (optional)"
              value={customDescription}
              onChange={(e) => setCustomDescription(e.target.value)}
              className="w-full bg-transparent border-b border-white/20 pb-2 text-sm focus:outline-none focus:border-white/60 placeholder:text-white/40 mb-4"
            />
            <button 
              onClick={handleCustomCharge}
              className="w-full bg-white text-primary font-bold py-3 rounded-xl hover:bg-blue-50 active:scale-[0.98] transition-all flex items-center justify-center gap-2"
            >
              <Scan size={18} />
              Scan to Collect
            </button>
          </div>
        </section>

        {/* Products Grid */}
        <section>
          <div className="flex items-center justify-between mb-4 px-1">
            <h3 className="font-bold text-gray-900 text-lg flex items-center gap-2">
              <Package size={20} className="text-primary" />
              Products
            </h3>
            <span className="text-xs font-medium text-gray-500 bg-white px-2 py-1 rounded-full border">
              {products?.length || 0} items
            </span>
          </div>

          <div className="grid grid-cols-2 gap-4">
            {loadingProducts ? (
              [1,2,3,4].map(i => (
                <div key={i} className="h-32 bg-gray-200 rounded-2xl animate-pulse" />
              ))
            ) : (
              products?.map((product) => (
                <motion.div
                  key={product.id}
                  whileHover={{ y: -4, shadow: "0 10px 25px -5px rgba(0, 0, 0, 0.1)" }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => handleProductClick(product)}
                  className="bg-white rounded-2xl p-4 border border-gray-100 shadow-sm cursor-pointer flex flex-col justify-between aspect-[4/5] relative overflow-hidden group"
                >
                  <div className="absolute top-0 right-0 p-3 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        onDeleteProduct(product.id, product.name);
                      }}
                      className="bg-destructive text-white rounded-full p-1.5 shadow-lg hover:bg-destructive/90"
                    >
                      <Trash2 size={14} />
                    </button>
                    <div className="bg-primary text-white rounded-full p-1.5 shadow-lg">
                      <ChevronRight size={14} />
                    </div>
                  </div>

                  <div className="flex-1 flex flex-col items-center justify-center text-center p-2">
                    {product.imageUrl ? (
                      <img src={product.imageUrl} alt={product.name} className="w-16 h-16 object-contain mb-3" />
                    ) : (
                      <div className="w-14 h-14 bg-blue-50 rounded-full flex items-center justify-center text-primary mb-3">
                        <Package size={24} />
                      </div>
                    )}
                    <h4 className="font-semibold text-gray-900 text-sm line-clamp-2 leading-tight">
                      {product.name}
                    </h4>
                  </div>
                  
                  <div className="mt-2 text-center">
                    <span className="block text-lg font-bold text-primary">
                      ${(product.price / 100).toFixed(2)}
                    </span>
                    <span className="text-[10px] text-gray-400 font-medium">Click to charge</span>
                  </div>
                </motion.div>
              ))
            )}
            
            {/* Add New Product */}
            <Dialog open={addProductOpen} onOpenChange={setAddProductOpen}>
              <DialogTrigger asChild>
                <div className="border-2 border-dashed border-gray-200 rounded-2xl flex flex-col items-center justify-center p-4 aspect-[4/5] hover:border-primary/50 hover:bg-blue-50/50 transition-colors cursor-pointer group">
                  <div className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center mb-2 group-hover:bg-primary group-hover:text-white transition-colors">
                    <Plus size={20} />
                  </div>
                  <span className="text-xs font-medium text-gray-500">Add Product</span>
                </div>
              </DialogTrigger>
              <DialogContent className="sm:max-w-md">
                <DialogHeader>
                  <DialogTitle>Add New Product</DialogTitle>
                </DialogHeader>
                <form onSubmit={productForm.handleSubmit(onAddProduct)} className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Product Name</Label>
                    <Input id="name" {...productForm.register("name")} placeholder="e.g. Hot Coffee" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="description">Description (optional)</Label>
                    <Textarea id="description" {...productForm.register("description")} placeholder="Describe your product..." />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="price">Price (in cents)</Label>
                    <Input id="price" type="number" {...productForm.register("price", { valueAsNumber: true })} placeholder="500 for $5.00" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="imageUrl">Image URL (optional)</Label>
                    <div className="flex gap-2">
                      <Input id="imageUrl" {...productForm.register("imageUrl")} placeholder="https://..." />
                      <Button type="button" variant="outline" size="icon" className="shrink-0">
                        <ImageIcon size={16} />
                      </Button>
                    </div>
                  </div>
                  <DialogFooter>
                    <Button type="submit" className="w-full" disabled={productForm.formState.isSubmitting}>
                      {productForm.formState.isSubmitting ? "Adding..." : "Add Product"}
                    </Button>
                  </DialogFooter>
                </form>
              </DialogContent>
            </Dialog>
          </div>
        </section>

        {/* Recent Transactions */}
        <section>
          <div className="flex items-center justify-between mb-4 px-1">
            <h3 className="font-bold text-gray-900 text-lg flex items-center gap-2">
              <History size={20} className="text-primary" />
              Recent Activity
            </h3>
            <Link href="#" className="text-xs font-medium text-primary hover:underline">
              View All
            </Link>
          </div>

          <div className="space-y-3">
            {loadingTransactions ? (
              <div className="text-center py-8 text-gray-400">Loading history...</div>
            ) : transactions?.length === 0 ? (
              <div className="text-center py-8 bg-white rounded-2xl border border-dashed border-gray-200">
                <p className="text-gray-400 text-sm">No transactions yet.</p>
              </div>
            ) : (
              transactions?.slice(0, 5).map((transaction, i) => (
                <TransactionCard key={transaction.id} transaction={transaction} index={i} />
              ))
            )}
          </div>
        </section>
      </main>

      {/* Scanner Modal */}
      <ScannerModal
        isOpen={scannerOpen}
        onClose={() => setScannerOpen(false)}
        onScan={handleScan}
        title={activeItem?.name || "Scan to Pay"}
        amount={activeItem?.price || 0}
        isProcessing={createTransaction.isPending}
      />
    </div>
  );
}
