import { useMerchants, useCreateMerchant, useDeleteMerchant } from "@/hooks/use-merchants";
import { Link } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { Store, ChevronRight, Search, MapPin, Plus, Trash2 } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertMerchantSchema } from "@shared/schema";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

export default function MerchantList() {
  const { data: merchants, isLoading, error } = useMerchants();
  const createMerchant = useCreateMerchant();
  const deleteMerchant = useDeleteMerchant();
  const { toast } = useToast();
  const [addMerchantOpen, setAddMerchantOpen] = useState(false);
  const [deletingId, setDeletingId] = useState<number | null>(null);
  const [selectedMerchantInfo, setSelectedMerchantInfo] = useState<any>(null);

  const merchantForm = useForm({
    resolver: zodResolver(insertMerchantSchema),
    defaultValues: {
      name: "",
      slug: "",
      description: "",
      logoUrl: "",
      pin: "1234",
      hours: "",
      location: ""
    }
  });

  const onAddMerchant = async (data: any) => {
    const adminPassword = prompt("Please enter admin password to add merchant:");
    if (!adminPassword) return;

    try {
      await createMerchant.mutateAsync({ ...data, adminPassword });
      setAddMerchantOpen(false);
      merchantForm.reset();
      toast({
        title: "Merchant Added",
        description: `${data.name} has been added to our network.`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to add merchant.",
        variant: "destructive",
      });
    }
  };

  const onDeleteMerchant = async (e: React.MouseEvent, id: number, name: string) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (!confirm(`Are you sure you want to delete ${name}? All its products and transactions will also be removed.`)) {
      return;
    }

    const adminPassword = prompt("Please enter admin password to delete merchant:");
    if (!adminPassword) return;

    try {
      setDeletingId(id);
      await deleteMerchant.mutateAsync({ id, adminPassword });
      toast({
        title: "Merchant Deleted",
        description: `${name} has been removed.`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to delete merchant.",
        variant: "destructive",
      });
    } finally {
      setDeletingId(null);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 border-4 border-primary/20 border-t-primary rounded-full animate-spin"></div>
          <p className="text-muted-foreground font-medium">Finding local merchants...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-gray-50 p-6 text-center">
        <div className="bg-red-50 p-4 rounded-full mb-4">
          <Store className="w-8 h-8 text-red-500" />
        </div>
        <h2 className="text-xl font-bold text-gray-900">Unable to load merchants</h2>
        <p className="text-gray-500 mt-2 mb-6">We couldn't connect to the server. Please try again.</p>
        <button onClick={() => window.location.reload()} className="px-6 py-2 bg-primary text-white rounded-lg font-medium">Retry</button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      {/* Header */}
      <header className="bg-white border-b sticky top-0 z-10">
        <div className="max-w-md mx-auto px-6 py-5 flex items-center justify-between">
          <div className="w-12" /> {/* Spacer */}
          <img src="https://storage.replit.com/py-wallet-assets/wallet.png" alt="PRWallet" className="h-12 w-auto object-contain" />
          
          <Dialog open={addMerchantOpen} onOpenChange={setAddMerchantOpen}>
            <DialogTrigger asChild>
              <button className="p-2 hover:bg-gray-100 rounded-full transition-colors">
                <Plus className="text-gray-600" size={24} />
              </button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md">
              <DialogHeader>
                <DialogTitle>Add New Merchant</DialogTitle>
              </DialogHeader>
              <form onSubmit={merchantForm.handleSubmit(onAddMerchant)} className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Business Name</Label>
                  <Input id="name" {...merchantForm.register("name")} placeholder="e.g. Sunrise Cafe" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="slug">URL Slug</Label>
                  <Input id="slug" {...merchantForm.register("slug")} placeholder="e.g. sunrise-cafe" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="description">Short Description</Label>
                  <Textarea id="description" {...merchantForm.register("description")} placeholder="Describe your business..." />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="logoUrl">Logo URL (optional)</Label>
                  <Input id="logoUrl" {...merchantForm.register("logoUrl")} placeholder="https://..." />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="pin">Access PIN (4 digits)</Label>
                  <Input id="pin" maxLength={4} {...merchantForm.register("pin")} placeholder="1234" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="hours">Business Hours</Label>
                  <Input id="hours" {...merchantForm.register("hours")} placeholder="e.g. 9AM - 5PM" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="location">Address / Location</Label>
                  <Input id="location" {...merchantForm.register("location")} placeholder="e.g. 123 Main St" />
                </div>
                <DialogFooter>
                  <Button type="submit" className="w-full" disabled={merchantForm.formState.isSubmitting}>
                    {merchantForm.formState.isSubmitting ? "Adding..." : "Register Merchant"}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </header>

      {/* Search Bar Placeholder */}
      <div className="max-w-md mx-auto px-6 py-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input 
            type="text" 
            placeholder="Search merchants..." 
            className="w-full pl-10 pr-4 py-3 bg-white border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all shadow-sm"
          />
        </div>
      </div>

      {/* Merchant List */}
      <div className="max-w-md mx-auto px-6 space-y-4">
            <AnimatePresence mode="popLayout">
              {merchants?.map((merchant, index) => (
                <motion.div
                  key={merchant.id}
                  layout
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ delay: index * 0.1 }}
                  className="relative group"
                >
                  <Link href={`/merchant/${merchant.id}`} className="block">
                    <div className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100 hover:shadow-md hover:border-primary/20 transition-all cursor-pointer flex items-center gap-4 active:scale-[0.98]">
                      {/* Logo / Icon */}
                      <div 
                        onClick={(e) => {
                          e.preventDefault();
                          e.stopPropagation();
                          setSelectedMerchantInfo(merchant);
                        }}
                        className="w-16 h-16 rounded-xl bg-gradient-to-br from-gray-50 to-gray-100 border border-gray-100 flex items-center justify-center shrink-0 overflow-hidden relative cursor-help"
                      >
                        {merchant.logoUrl ? (
                          <img src={merchant.logoUrl} alt={merchant.name} className="w-full h-full object-cover" />
                        ) : (
                          <Store className="w-8 h-8 text-primary/40 group-hover:text-primary transition-colors" />
                        )}
                        
                        {/* Online Status Dot */}
                        <div className="absolute top-1 right-1 w-2.5 h-2.5 rounded-full bg-green-500 border-2 border-white"></div>
                      </div>

                      <div className="flex-1 min-w-0">
                        <h3 className="font-bold text-gray-900 group-hover:text-primary transition-colors truncate">
                          {merchant.name}
                        </h3>
                        <p className="text-sm text-gray-500 truncate mt-0.5">{merchant.description || "Local Business"}</p>
                        
                        <div className="flex items-center gap-1 mt-2 text-xs text-gray-400 font-medium">
                          <MapPin size={12} />
                          <span>0.8 miles away</span>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 text-gray-400 hover:text-destructive hover:bg-destructive/10 z-20"
                          disabled={deletingId === merchant.id}
                          onClick={(e) => onDeleteMerchant(e, merchant.id, merchant.name)}
                        >
                          <Trash2 size={16} />
                        </Button>
                        <div className="w-8 h-8 rounded-full bg-gray-50 flex items-center justify-center text-gray-400 group-hover:bg-primary group-hover:text-white transition-colors">
                          <ChevronRight size={16} />
                        </div>
                      </div>
                    </div>
                  </Link>
                </motion.div>
              ))}
            </AnimatePresence>

        {merchants?.length === 0 && (
          <div className="text-center py-12">
            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Store className="w-8 h-8 text-gray-400" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900">No merchants found</h3>
            <p className="text-gray-500 mt-1">Be the first to join our network!</p>
          </div>
        )}
      </div>

      <Dialog open={!!selectedMerchantInfo} onOpenChange={() => setSelectedMerchantInfo(null)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{selectedMerchantInfo?.name}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-1">
              <Label className="text-xs uppercase text-muted-foreground">About</Label>
              <p className="text-sm">{selectedMerchantInfo?.description || "No description available."}</p>
            </div>
            <div className="flex items-start gap-3">
              <MapPin className="w-4 h-4 text-primary shrink-0 mt-0.5" />
              <div className="space-y-1">
                <Label className="text-xs uppercase text-muted-foreground">Location</Label>
                {selectedMerchantInfo?.location ? (
                  <p className="text-sm">{selectedMerchantInfo.location}</p>
                ) : (
                  <button 
                    onClick={() => {
                      setSelectedMerchantInfo(null);
                      setAddMerchantOpen(true);
                    }}
                    className="text-sm text-primary hover:underline flex items-center gap-1"
                  >
                    <Plus size={12} /> Add Location
                  </button>
                )}
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Search className="w-4 h-4 text-primary shrink-0 mt-0.5" />
              <div className="space-y-1">
                <Label className="text-xs uppercase text-muted-foreground">Hours</Label>
                {selectedMerchantInfo?.hours ? (
                  <p className="text-sm">{selectedMerchantInfo.hours}</p>
                ) : (
                  <button 
                    onClick={() => {
                      setSelectedMerchantInfo(null);
                      setAddMerchantOpen(true);
                    }}
                    className="text-sm text-primary hover:underline flex items-center gap-1"
                  >
                    <Plus size={12} /> Add Hours
                  </button>
                )}
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button onClick={() => setSelectedMerchantInfo(null)} className="w-full">Close</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
