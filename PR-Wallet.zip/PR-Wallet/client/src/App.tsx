import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import MerchantList from "@/pages/MerchantList";
import MerchantDashboard from "@/pages/MerchantDashboard";
import MerchantLogin from "@/pages/MerchantLogin";

function Router() {
  return (
    <Switch>
      <Route path="/" component={MerchantList} />
      <Route path="/merchant/:id/login" component={MerchantLogin} />
      <Route path="/merchant/:id" component={MerchantDashboard} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
