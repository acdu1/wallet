import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl, type CreateTransactionInput } from "@shared/routes";
import { z } from "zod";

// ============================================
// MERCHANTS
// ============================================

export function useMerchants() {
  return useQuery({
    queryKey: [api.merchants.list.path],
    queryFn: async () => {
      const res = await fetch(api.merchants.list.path);
      if (!res.ok) throw new Error("Failed to fetch merchants");
      return api.merchants.list.responses[200].parse(await res.json());
    },
  });
}

export function useMerchant(id: number) {
  return useQuery({
    queryKey: [api.merchants.get.path, id],
    enabled: !!id,
    queryFn: async () => {
      const url = buildUrl(api.merchants.get.path, { id });
      const res = await fetch(url);
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch merchant");
      return api.merchants.get.responses[200].parse(await res.json());
    },
  });
}

export function useCreateMerchant() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: any & { adminPassword?: string }) => {
      const { adminPassword, ...merchantData } = data;
      const res = await fetch(api.merchants.create.path, {
        method: 'POST',
        headers: { 
          "Content-Type": "application/json",
          "X-Admin-Password": adminPassword || ""
        },
        body: JSON.stringify(merchantData),
      });
      if (!res.ok) {
        const error = await res.json().catch(() => ({ message: "Failed to create merchant" }));
        throw new Error(error.message);
      }
      return api.merchants.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.merchants.list.path] });
    },
  });
}

export function useDeleteMerchant() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, adminPassword }: { id: number, adminPassword?: string }) => {
      const res = await fetch(buildUrl(api.merchants.delete.path, { id }), {
        method: 'DELETE',
        headers: {
          "X-Admin-Password": adminPassword || ""
        }
      });
      if (!res.ok) {
        const error = await res.json().catch(() => ({ message: "Failed to delete merchant" }));
        throw new Error(error.message);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.merchants.list.path] });
    },
  });
}

// ============================================
// PRODUCTS
// ============================================

export function useMerchantProducts(merchantId: number) {
  return useQuery({
    queryKey: [api.products.listByMerchant.path, merchantId],
    enabled: !!merchantId,
    queryFn: async () => {
      const url = buildUrl(api.products.listByMerchant.path, { id: merchantId });
      const res = await fetch(url);
      if (!res.ok) throw new Error("Failed to fetch products");
      return api.products.listByMerchant.responses[200].parse(await res.json());
    },
  });
}

// ============================================
// TRANSACTIONS
// ============================================

export function useMerchantTransactions(merchantId: number) {
  return useQuery({
    queryKey: [api.transactions.listByMerchant.path, merchantId],
    enabled: !!merchantId,
    queryFn: async () => {
      const url = buildUrl(api.transactions.listByMerchant.path, { id: merchantId });
      const res = await fetch(url);
      if (!res.ok) throw new Error("Failed to fetch transactions");
      return api.transactions.listByMerchant.responses[200].parse(await res.json());
    },
  });
}

export function useCreateTransaction() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (data: CreateTransactionInput) => {
      // Validate with shared schema before sending
      const validated = api.transactions.create.input.parse(data);
      
      const res = await fetch(api.transactions.create.path, {
        method: api.transactions.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
      });

      if (!res.ok) {
        if (res.status === 400) {
          const error = api.transactions.create.responses[400].parse(await res.json());
          throw new Error(error.message);
        }
        throw new Error("Failed to create transaction");
      }

      return api.transactions.create.responses[201].parse(await res.json());
    },
    onSuccess: (_, variables) => {
      // Invalidate relevant queries to refresh lists
      queryClient.invalidateQueries({ 
        queryKey: [api.transactions.listByMerchant.path, variables.merchantId] 
      });
    },
  });
}
