import { type Transaction } from "@shared/schema";
import { formatDistanceToNow } from "date-fns";
import { CheckCircle2, Clock, Smartphone, Info } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

export function TransactionCard({ transaction, index }: { transaction: Transaction, index: number }) {
  const [detailsOpen, setDetailsOpen] = useState(false);
  const formattedAmount = new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD'
  }).format(transaction.amount / 100);

  return (
    <>
      <motion.div 
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: index * 0.05 }}
        onClick={() => setDetailsOpen(true)}
        className="bg-white rounded-xl p-4 border border-border shadow-sm hover:shadow-md transition-shadow flex items-center justify-between group cursor-pointer"
      >
        <div className="flex items-center gap-4">
          <div className={`
            w-10 h-10 rounded-full flex items-center justify-center
            ${transaction.status === 'completed' ? 'bg-green-100 text-green-600' : 'bg-amber-100 text-amber-600'}
          `}>
            {transaction.status === 'completed' ? <CheckCircle2 size={20} /> : <Clock size={20} />}
          </div>
          
          <div>
            <h4 className="font-semibold text-sm text-foreground">{transaction.description}</h4>
            <div className="flex items-center gap-2 text-xs text-muted-foreground mt-0.5">
              <span>{transaction.createdAt ? formatDistanceToNow(new Date(transaction.createdAt), { addSuffix: true }) : 'Just now'}</span>
              <span>•</span>
              <span className="flex items-center gap-1">
                <Smartphone size={10} />
                {transaction.customerQrCode.substring(0, 8)}...
              </span>
            </div>
          </div>
        </div>

        <div className="text-right">
          <span className="block font-bold text-foreground">{formattedAmount}</span>
          <span className={`text-xs capitalize ${transaction.status === 'completed' ? 'text-green-600' : 'text-amber-600'}`}>
            {transaction.status}
          </span>
        </div>
      </motion.div>

      <Dialog open={detailsOpen} onOpenChange={setDetailsOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Info className="w-5 h-5 text-primary" />
              Transaction Details
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="flex justify-between items-center pb-2 border-b">
              <span className="text-sm text-muted-foreground">Amount</span>
              <span className="text-lg font-bold text-primary">{formattedAmount}</span>
            </div>
            <div className="flex justify-between items-center pb-2 border-b">
              <span className="text-sm text-muted-foreground">Description</span>
              <span className="text-sm font-medium">{transaction.description}</span>
            </div>
            <div className="flex justify-between items-center pb-2 border-b">
              <span className="text-sm text-muted-foreground">Customer QR</span>
              <span className="text-sm font-mono bg-muted px-2 py-1 rounded truncate max-w-[200px]" title={transaction.customerQrCode}>
                {transaction.customerQrCode}
              </span>
            </div>
            <div className="flex justify-between items-center pb-2 border-b">
              <span className="text-sm text-muted-foreground">Status</span>
              <span className={`text-sm font-bold capitalize ${transaction.status === 'completed' ? 'text-green-600' : 'text-amber-600'}`}>
                {transaction.status}
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">Date & Time</span>
              <span className="text-sm">
                {transaction.createdAt ? new Date(transaction.createdAt).toLocaleString() : 'N/A'}
              </span>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
