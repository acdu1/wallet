import { useState, useEffect } from "react";
import { Scanner } from "@yudiel/react-qr-scanner";
import { X, CheckCircle2, Loader2, Scan } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { Dialog, DialogContent } from "@/components/ui/dialog";

interface ScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onScan: (data: string) => void;
  title: string;
  amount: number;
  isProcessing: boolean;
}

export function ScannerModal({
  isOpen,
  onClose,
  onScan,
  title,
  amount,
  isProcessing
}: ScannerModalProps) {
  const [hasScanned, setHasScanned] = useState(false);

  // Reset state when modal opens
  useEffect(() => {
    if (isOpen) {
      setHasScanned(false);
    }
  }, [isOpen]);

  const handleScan = (result: string | null) => {
    if (result && !hasScanned && !isProcessing) {
      setHasScanned(true);
      onScan(result);
    }
  };

  const formattedAmount = new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD'
  }).format(amount / 100);

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-md p-0 overflow-hidden bg-background border-none shadow-2xl rounded-3xl">
        <div className="relative flex flex-col items-center justify-center min-h-[500px]">
          
          {/* Header */}
          <div className="absolute top-0 left-0 right-0 z-20 p-6 bg-gradient-to-b from-black/60 to-transparent">
            <div className="flex items-center justify-between text-white">
              <div>
                <h3 className="text-lg font-bold font-display">{title}</h3>
                <p className="text-white/80 font-medium text-xl">{formattedAmount}</p>
              </div>
              <button 
                onClick={onClose}
                className="p-2 bg-white/10 backdrop-blur-md rounded-full hover:bg-white/20 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Scanner or Loading State */}
          <div className="w-full h-full absolute inset-0 bg-black">
            {!isProcessing ? (
              <Scanner
                onScan={(results) => handleScan(results[0]?.rawValue || null)}
                onError={(error) => console.log(error?.message)}
                formats={[
                  "qr_code",
                  "ean_13",
                  "ean_8",
                  "code_128",
                  "code_39",
                  "upc_a",
                  "upc_e"
                ]}
                styles={{ container: { height: '100%', width: '100%' }, video: { objectFit: 'cover' } }}
              />
            ) : (
              <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/90 z-30">
                <Loader2 className="w-16 h-16 text-primary animate-spin mb-4" />
                <p className="text-white font-medium text-lg">Processing Payment...</p>
              </div>
            )}
            
            {/* Overlay Grid */}
            {!isProcessing && (
              <div className="absolute inset-0 z-10 pointer-events-none">
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 border-2 border-white/30 rounded-3xl overflow-hidden">
                  <div className="absolute top-0 left-0 w-full h-1 bg-primary shadow-[0_0_20px_rgba(59,130,246,1)] animate-scan"></div>
                  
                  {/* Corners */}
                  <div className="absolute top-0 left-0 w-8 h-8 border-t-4 border-l-4 border-primary rounded-tl-xl"></div>
                  <div className="absolute top-0 right-0 w-8 h-8 border-t-4 border-r-4 border-primary rounded-tr-xl"></div>
                  <div className="absolute bottom-0 left-0 w-8 h-8 border-b-4 border-l-4 border-primary rounded-bl-xl"></div>
                  <div className="absolute bottom-0 right-0 w-8 h-8 border-b-4 border-r-4 border-primary rounded-br-xl"></div>
                </div>
                <div className="absolute bottom-12 left-0 right-0 text-center text-white/80 text-sm font-medium">
                  Align QR code within the frame
                </div>
              </div>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
